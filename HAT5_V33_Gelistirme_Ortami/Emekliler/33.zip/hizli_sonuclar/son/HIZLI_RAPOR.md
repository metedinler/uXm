# HIZLI_TARA

- kaynak: `C:\Users\mete\Downloads\1\UXMv33\sonuclar_bellek\kosu_20260510_202456\sonuclar.csv`
- total/toplam: 5
- hatalı_satır: 0
- tekil_hatalı_anahtar: 0
- manifest: `C:\Users\mete\Downloads\1\UXMv33\hizli_sonuclar\son\hatali_tekil_manifest.csv`
